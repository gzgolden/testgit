//
//  ViewController.m
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "ViewController.h"
#import "MMAsyncTaskPool.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
//    NSString* hello = [NSString stringWithFormat:@"%d",6666];
//    MMAsyncTaskPool* taskPool = [MMAsyncTaskPool shareInstance];
//    [taskPool startAsyncTask:self sel:@selector(asyncTask:str2:) arguments:hello,hello,nil];
//    
//    
//    NSTimer* timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(onTimer:) userInfo:nil repeats:YES];
    
}

- (void)onTimer:(id)timer
{
//    static NSInteger s_cnt = 0;
//    s_cnt++;
//    MMAsyncTaskPool* taskPool = [MMAsyncTaskPool shareInstance];
//    NSString* str = [NSString stringWithFormat:@"%@",@"goldenliu"];
////    [taskPool startAsyncTask:self sel:@selector(asyncTask2:number:) arguments:str,[NSNumber numberWithInt:888888],nil];
//   // NSLog(@"ontimer:%d",s_cnt);
//    [taskPool startAsyncTaskWithBlock:^{
//        NSLog(@"onTimer:%d",s_cnt);
//    }];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)asyncTask:(NSString*)str str2:(NSString*)str2
{
    NSLog(@"str:%@,str2:%@",str,str2);
}

- (void)asyncTask2:(NSString*)str number:(NSNumber*)number
{
    NSLog(@"str:%@,number:%@",str,number);
}
@end

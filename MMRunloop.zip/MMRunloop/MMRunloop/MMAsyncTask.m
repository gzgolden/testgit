//
//  MMAsyncTask.m
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "MMAsyncTask.h"

@implementation MMAsyncTask
@synthesize runloopSrc = _runloopSrc;

- (BOOL)isConcurrent
{
    return YES;
}

- (BOOL)isExecuting
{
    return _bExecuting;
}

- (BOOL)isFinished
{
    return _bFinished;
}

- (void)start
{
    if ([self isCancelled])
    {
        [self willChangeValueForKey:@"isFinished"];
        _bFinished = YES;
        [self didChangeValueForKey:@"isFinished"];
        
        return;
    }
    
    [self willChangeValueForKey:@"isExecuting"];
    _bExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    
    NSRunLoop* threadRunloop = [NSRunLoop currentRunLoop];
    [_runloopSrc hookIntoRunloop:threadRunloop];
    [threadRunloop run];
}
@end

//
//  NSOperationDemo.h
//  MMRunloop
//
//  Created by goldenliu on 14-7-23.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSOperationDemo : NSObject

+ (void)testNSOperation;
@end

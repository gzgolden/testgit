//
//  MMAsyncTaskPool.m
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "MMAsyncTaskPool.h"
#import "MMRunloopSource.h"
#import "MMAsyncTask.h"
static MMAsyncTaskPool* s_gAsyncTaskPool = nil;

@implementation MMAsyncTaskPool
{
    NSOperationQueue*  _operationQueue;
    MMRunloopSource*  _normalAsyncTask;
    MMRunloopSource*  _eventAsyncTask;
}

+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        s_gAsyncTaskPool = [[MMAsyncTaskPool alloc] init];
    });
    
    return s_gAsyncTaskPool;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        _operationQueue = [[NSOperationQueue alloc] init];
    }
    return self;
}

- (void)startAsyncTask:(id)target sel:(SEL)sel arguments:(id)arg1, ...
{
    [self internalStartupNormalAsyncTask];
    NSMutableArray *arrArguments = [NSMutableArray array];
    [arrArguments addObject:arg1];
    id arg = nil;
    va_list argList;
    va_start(argList, arg1);
    while ((arg = va_arg(argList, id)))
    {
        if (arg)
        {
            [arrArguments addObject:arg];
        }
    }
    va_end(argList);

    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[(NSObject*)target methodSignatureForSelector:sel]];
    invocation.target = target;
    invocation.selector = sel;
    
    for (NSInteger index = 0; index < arrArguments.count; index++)
    {
        id arg = [arrArguments objectAtIndex:index];
        [invocation setArgument:&arg atIndex:(2+ index)];
    }
    [invocation retainArguments];
    MMInvocationWrap* invocationWrap = [[MMInvocationWrap alloc] initWithInvocation:invocation target:target];
    if ([_normalAsyncTask runloop])
    {
        [_normalAsyncTask postMessage:invocationWrap];
    }
    else
    {
        [_normalAsyncTask postMessageToWaitqueue:invocationWrap];
    }
    [invocationWrap release];
    
}

- (void)startAsyncTaskWithBlock:(AsyncTaskBlock)block
{
    [self internalStartupNormalAsyncTask];
    AsyncTaskBlock copyBlock = [[block copy] autorelease];
    if ([_normalAsyncTask runloop])
    {
        [_normalAsyncTask postMessageWithBlock:copyBlock];
    }
    else
    {
        [_normalAsyncTask postMessageWithBlockToWaitQueue:copyBlock];
    }
}

#pragma mark -
#pragma mark - Internal Method
- (void)internalStartupNormalAsyncTask
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _normalAsyncTask = [[MMRunloopSource alloc] init];
        MMAsyncTask* oAsyncTask = [[MMAsyncTask alloc] init];
        oAsyncTask.runloopSrc = _normalAsyncTask;
        [_operationQueue addOperation:oAsyncTask];
        [oAsyncTask release];
    });

}
@end

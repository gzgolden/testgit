//
//  MMOperation.h
//  MMRunloop
//
//  Created by goldenliu on 14-7-23.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMOperation : NSOperation
{
    BOOL _bExecuting;
    BOOL _bFinished;
    BOOL _bCancelled;
    NSString*  _identifier;
}

- (id)initWithIdentifier:(NSString*)identifier;
@end

//
//  MMAsyncTaskPool.h
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMRunloopSource.h"
@interface MMAsyncTaskPool : NSObject

+ (instancetype)shareInstance;
- (void)startAsyncTask:(id)target sel:(SEL)sel arguments:(id)arg1,...;
- (void)startAsyncTaskWithBlock:(AsyncTaskBlock)block;
@end

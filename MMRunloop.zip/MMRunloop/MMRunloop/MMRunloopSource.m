//
//  MMRunloopSource.m
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "MMRunloopSource.h"

static void RunLoopSourceScheduleRoutine(void *info, CFRunLoopRef rl, CFStringRef mode)
{
    
}

static void RunLoopSourcePerformRoutine(void *info)
{
    MMRunloopSource* runloopSource = (MMRunloopSource*)info;
    [runloopSource fired];
}

static void RunLoopSourceCancelRoutine(void *info, CFRunLoopRef rl, CFStringRef mode)
{
    
}

@implementation MMInvocationWrap
@synthesize invocation = _invocation;
- (id)initWithInvocation:(NSInvocation *)invocation target:(id)target
{
    self = [super init];
    if (self)
    {
        _invocation = [invocation retain];
        _target = [target retain];
    }
    return self;
}

- (void)dealloc
{
    [_invocation release];
    [_target release];
    [super dealloc];
}
@end

@implementation MMRunloopSource
{
    CFRunLoopSourceRef _runloopSource;
    NSRunLoop *_runloop;
    NSMutableArray *_invocations;
    NSMutableArray *_invocationsWithBlock;
    
    NSRecursiveLock *_invocationLock;
}
@synthesize runloop = _runloop;

- (id)init
{
    self = [super init];
    if (self)
    {
        CFRunLoopSourceContext context = {0,(void*)self,NULL,NULL,NULL,NULL,NULL,
            NULL,
            NULL,
            &RunLoopSourcePerformRoutine};
        _runloopSource = CFRunLoopSourceCreate(kCFAllocatorDefault, 0, &context);
        _invocations = [[NSMutableArray alloc] init];
        _invocationsWithBlock = [[NSMutableArray alloc] init];
        _invocationLock = [[NSRecursiveLock alloc] init];

    }
    
    return self;
}

- (void)dealloc
{
    CFRelease(_runloopSource);
    [_invocations release];
    [self unhookFromCurrentRunLoop];
    [_runloop release];
    [_invocationsWithBlock release];
    [_invocationLock release];
    [super dealloc];
}

- (void)hookIntoRunloop:(NSRunLoop *)runloop
{
    [_invocationLock lock];
    [self fired];
    self.runloop = runloop;
    [_invocationLock unlock];
    CFRunLoopAddSource([_runloop getCFRunLoop], _runloopSource, kCFRunLoopDefaultMode);
}

- (void)unhookFromCurrentRunLoop
{
    CFRunLoopRemoveSource([_runloop getCFRunLoop], _runloopSource, kCFRunLoopDefaultMode);
}

- (void)postMessage:(MMInvocationWrap *)invocation
{
    [_invocationLock lock];
    [_invocations addObject:invocation];
    [self firedSource];
    [_invocationLock unlock];
    
}

- (void)postMessageToWaitqueue:(MMInvocationWrap *)invocation
{
    [_invocationLock lock];
    [_invocations addObject:invocation];
    [_invocationLock unlock];
}

- (void)postMessageWithBlock:(AsyncTaskBlock)block
{
    [_invocationLock lock];
    [_invocationsWithBlock addObject:block];
    [self firedSource];
    [_invocationLock unlock];
}

- (void)postMessageWithBlockToWaitQueue:(AsyncTaskBlock)block
{
    [_invocationLock lock];
    [_invocationsWithBlock addObject:block];
    [_invocationLock unlock];
}
- (void)firedSource
{
    CFRunLoopSourceSignal(_runloopSource);
    CFRunLoopWakeUp([_runloop getCFRunLoop]);
}

- (void)fired
{
    NSArray* tmpInvocations = nil;
    NSArray* tmpInvocationsBlock = nil;
    
    [_invocationLock lock];
    tmpInvocations = [NSArray arrayWithArray:_invocations];
    [_invocations removeAllObjects];
    tmpInvocationsBlock = [NSArray arrayWithArray:_invocationsWithBlock];
    [_invocationsWithBlock removeAllObjects];
    [_invocationLock unlock];
    
    
    for (int i = 0; i < [tmpInvocations count]; i++)
    {
        MMInvocationWrap* invocationWrap = [tmpInvocations objectAtIndex:i];
        [invocationWrap.invocation invoke];
    }
    
    for (int i = 0; i < [tmpInvocationsBlock count]; i++)
    {
        AsyncTaskBlock block = [tmpInvocationsBlock objectAtIndex:i];
        block();
    }

}
@end

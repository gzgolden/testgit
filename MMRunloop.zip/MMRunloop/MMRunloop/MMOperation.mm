//
//  MMOperation.m
//  MMRunloop
//
//  Created by goldenliu on 14-7-23.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "MMOperation.h"

@implementation MMOperation
- (id)initWithIdentifier:(NSString *)identifier
{
    self = [super init];
    if (self)
    {
        _identifier = [identifier copy];
    }
    return self;
}

- (void)dealloc
{
    [_identifier release];
    [super dealloc];
}

- (BOOL)isConcurrent
{
    return YES;
}

- (BOOL)isExecuting
{
    return _bExecuting;
}

- (BOOL)isFinished
{
    return _bFinished;
}

- (void)main
{
    @autoreleasepool
    {
        for(int i = 0;i < 10;i++)
        {
            NSLog(@"operation:%@ running-->index:%d",_identifier,i);
        }
        
        [self completeOperation];
    }
}

- (void)start
{
    if ([self isCancelled])
    {
        [self willChangeValueForKey:@"isFinished"];
        _bFinished = YES;
        [self didChangeValueForKey:@"isFinished"];
        
        return;
    }
    
    [self willChangeValueForKey:@"isExecuting"];
    _bExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    [self main];
}

- (void)completeOperation
{
    [self willChangeValueForKey:@"isFinished"];
    [self willChangeValueForKey:@"isExecuting"];
    _bFinished = YES;
    _bExecuting = NO;
    [self didChangeValueForKey:@"isExecuting"];
    [self didChangeValueForKey:@"isFinished"];
}
@end

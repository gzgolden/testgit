//
//  AppDelegate.m
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "AppDelegate.h"
#import "MMRunloopSource.h"
#import "GCDDemo.h"
#import "NSOperationDemo.h"
static void myRunloopObserver (CFRunLoopObserverRef observer, CFRunLoopActivity activity, void *info)
{
    switch (activity)
    {
        case kCFRunLoopEntry:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopEntry");
            break;
        case kCFRunLoopAfterWaiting:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopAfterWaiting");
            break;
        case kCFRunLoopAllActivities:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopAllActivities");
            break;
        case kCFRunLoopBeforeSources:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopBeforeSources");
            break;
        case kCFRunLoopBeforeTimers:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopBeforeTimers");
            break;
        case kCFRunLoopBeforeWaiting:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopBeforeWaiting");
            break;
        case kCFRunLoopExit:
            NSLog(@"myRunloopObserver-->activity:kCFRunLoopExit");
            break;
            
        default:
            break;
    }
}
@implementation AppDelegate
{
    NSThread*  _thread;
    MMRunloopSource*  _runloopSource;
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    //测试runloop和通过runloopSource实现线程间通信
    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(onMainThreadTimer:) userInfo:nil repeats:YES];
   _thread = [[NSThread alloc] initWithTarget:self selector:@selector(onThreadRun:) object:nil];
    [_thread start];
   
   _runloopSource = [[MMRunloopSource alloc] init];
    
    //GCD demo
    //[GCDDemo demoStart];
    
    //NSOperation demo
    //[NSOperationDemo testNSOperation];
    
    return YES;
}

- (void)onThreadRun:(id)obj
{
    @autoreleasepool
    {
        while (true)
        {
            static NSInteger g_cnt = 0;
            NSRunLoop* runloop = [NSRunLoop currentRunLoop];
           // NSLog(@"thread running:%d,runloop:%p",g_cnt,runloop);
            
            CFRunLoopObserverContext context = {0,self,NULL,NULL,NULL};
            CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault, kCFRunLoopAllActivities, YES, 0, &myRunloopObserver, &context);
            if (observer)
            {
                CFRunLoopRef cfLoop = [runloop getCFRunLoop];
                CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
            }
            
            [_runloopSource hookIntoRunloop:runloop];
            if (g_cnt == 0)
            {
                NSTimer* timer = [NSTimer timerWithTimeInterval:3 target:self selector:@selector(onThreadTimer:) userInfo:nil repeats:YES];
                [runloop addTimer:timer forMode:NSDefaultRunLoopMode];
                NSLog(@"timer added to runloop:%p",runloop);
//                [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onThreadTimer:) userInfo:nil repeats:YES];
            }
            g_cnt++;
            //[runloop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:3]];
            [runloop run];
        }
    }
}

- (void)onThreadTimer:(id)timer
{
    static NSInteger g_timerCnt = 0;
    NSRunLoop* runloop = [NSRunLoop currentRunLoop];
    
    NSLog(@"onThreadTimer running:%d,runloop:%p",g_timerCnt,runloop);
    g_timerCnt++;
}

- (void)onMainThreadTimer:(id)timer
{
    static NSInteger g_mainTimerCnt = 0;
    NSLog(@"onMainThreadTimer running:%d",g_mainTimerCnt);
    g_mainTimerCnt++;
//    [self performSelector:@selector(doSomethingOnThread:) onThread:_thread withObject:[NSNumber numberWithInt:g_mainTimerCnt] waitUntilDone:NO];
    
    
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[(NSObject*)self methodSignatureForSelector:@selector(processInputSource)]];
    invocation.target = self;
    invocation.selector = @selector(processInputSource);
    
    MMInvocationWrap* wrap = [[MMInvocationWrap alloc] initWithInvocation:invocation target:self];
    if ([_runloopSource runloop])
    {
        [_runloopSource postMessage:wrap];
    }
    else
    {
        [_runloopSource postMessageToWaitqueue:wrap];
    }
    
    [wrap release];
}

- (void)doSomethingOnThread:(NSNumber*)nsObj
{
    NSLog(@"doSomethingOnThread:%@",nsObj);
}

- (void)processInputSource
{
    NSLog(@"processInputSource");
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end

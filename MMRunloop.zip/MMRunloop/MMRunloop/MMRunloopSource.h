//
//  MMRunloopSource.h
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^AsyncTaskBlock)(void);

@interface MMInvocationWrap : NSObject
{
    NSInvocation*  _invocation;
    id   _target;
}

- (id)initWithInvocation:(NSInvocation*)invocation target:(id)target;
@property(nonatomic,readonly) NSInvocation* invocation;
@end

@interface MMRunloopSource : NSObject
{
   
}
@property(nonatomic,retain) NSRunLoop *runloop;
- (void)fired;
- (void)hookIntoRunloop:(NSRunLoop*)runloop;
- (void)unhookFromCurrentRunLoop;
- (void)postMessage:(MMInvocationWrap*)invocation;
- (void)firedSource;
- (void)postMessageToWaitqueue:(MMInvocationWrap*)invocation;
- (void)postMessageWithBlock:(AsyncTaskBlock)block;
- (void)postMessageWithBlockToWaitQueue:(AsyncTaskBlock)block;
@end

//
//  GCDDemo.m
//  MMRunloop
//
//  Created by goldenliu on 14-7-23.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "GCDDemo.h"

dispatch_semaphore_t taskSem = dispatch_semaphore_create(0);

dispatch_block_t task1 = ^(void)
{
    for(int i = 0;i < 10;i++)
    {
        NSLog(@"task1-->index:%d",i);
    }
    
    dispatch_semaphore_signal(taskSem);
};

dispatch_block_t task2 = ^(void){
    
    dispatch_semaphore_wait(taskSem, DISPATCH_TIME_FOREVER);
    for(int i = 0;i < 10;i++)
    {
        NSLog(@"task2-->index:%d",i);
    }
};
@implementation GCDDemo

+ (void)demoStart
{
    //[GCDDemo testSerailQueue];
    //[GCDDemo testConcurrentQueue];
    [GCDDemo testDispatchGroup];
}

+ (void)testSerailQueue
{
    dispatch_queue_t queue = dispatch_queue_create("mytest", NULL);
    dispatch_async(queue, task1);
    dispatch_async(queue, task2);
}

+ (void)testConcurrentQueue
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, task1);
    dispatch_async(queue, task2);
}

+ (void)testDispatchGroup
{
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_group_async(group, queue, task1);
    dispatch_group_async(group, queue, task2);
    
    NSLog(@"start to wait task");
    dispatch_group_wait(group, DISPATCH_TIME_FOREVER);
    NSLog(@"end to wait task");
    
    dispatch_release(group);
}
@end

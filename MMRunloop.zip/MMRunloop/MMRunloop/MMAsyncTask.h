//
//  MMAsyncTask.h
//  MMRunloop
//
//  Created by goldenliu on 14-4-1.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMRunloopSource.h"
@interface MMAsyncTask : NSOperation
{
    MMRunloopSource *_runloopSrc;
    BOOL _bExecuting;
    BOOL _bFinished;
    BOOL _bCancelled;
}
@property(nonatomic,assign) MMRunloopSource *runloopSrc;

@end

//
//  NSOperationDemo.m
//  MMRunloop
//
//  Created by goldenliu on 14-7-23.
//  Copyright (c) 2014年 goldenliu. All rights reserved.
//

#import "NSOperationDemo.h"

#import "MMOperation.h"
@implementation NSOperationDemo

+ (void)testNSOperation
{
    NSOperationQueue* queue = [[NSOperationQueue alloc] init];
    MMOperation* operation1 = [[MMOperation alloc] initWithIdentifier:@"operation1"];
    MMOperation* operation2 = [[MMOperation alloc] initWithIdentifier:@"operation2"];
    
    [operation2 addDependency:operation1];
    [queue addOperation:operation1];
    [queue addOperation:operation2];
}
@end
